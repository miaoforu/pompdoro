package song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.Logic.SubEvent;
import song.softdev.kuleuven.pomodoro.R;

public class SubEventListAdapter extends BaseAdapter {
    private List<SubEvent> list=new ArrayList<>();
    private Context mContext;
    private LayoutInflater layoutInflater;
    @SuppressLint("UseSparseArrays")
    private Map<Integer,Boolean> isCheck= new HashMap<>();

    public SubEventListAdapter(Context mContext){
        super();
        this.mContext=mContext;
        this.layoutInflater=LayoutInflater.from(mContext);
//        initCheck(false);
    }
    // 初始化map集合
//    public void initCheck(boolean flag){
//        for(int i=0;i<list.size();i++){
//            isCheck.put(i,flag);
//        }
//    }
    public void setData(Event data){
        this.list=data.getSubEvents();
    }
    public void addData(SubEvent event){
        list.add(0,event);
    }


    @Override
    public int getCount() {
        return list!=null?list.size():0;
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        SubViewHolder viewHolder=null;
        if(convertView==null){
            convertView= LayoutInflater.from(mContext).inflate(R.layout.sub_item,parent,false);
            viewHolder=new SubViewHolder();
            viewHolder.finish=convertView.findViewById(R.id.subEventfinish);
            viewHolder.textView=convertView.findViewById(R.id.subEventTitle);
            viewHolder.delete=convertView.findViewById(R.id.subEventDelete);
            convertView.setTag(viewHolder);
        }else {
            viewHolder=(SubViewHolder)convertView.getTag();
        }
        //拿到对象填充数据
        final SubEvent event=list.get(position);
        viewHolder.textView.setText(event.getName());
        viewHolder.finish.setChecked(event.getFinished());

        viewHolder.finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                event.setFinished(!event.getFinished());
                int finished=event.getFinished()?1:0;
                ((EventSetting)mContext).getThreadArrayList().add(new Thread(()-> {
                    RequestQueue requestQueue = Volley.newRequestQueue(mContext);
                    String url = "https://studev.groept.be/api/a18_sd611/finishSubEvent/" +finished + "/" + event.getId();
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            response -> {},
                            error -> {});
                    requestQueue.add(stringRequest);
                }));
            }
        });


//        if(isCheck.get(position)==null){
//            isCheck.put(position,false);
//        }

   //     viewHolder.finish.setChecked(list.get(position).getFinished());
        final EditText texttview=viewHolder.textView;
        texttview.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent eevent) {
                //如果按回车
                if (actionId == EditorInfo.IME_ACTION_DONE ) {
                    if (!texttview.getText().toString().equals("")&&!texttview.getText().toString().equals(event.getName())) {

                        event.setName(texttview.getText().toString());
                        ((EventSetting)mContext).getThreadArrayList().add(new Thread(()-> {
                            RequestQueue requestQueue = Volley.newRequestQueue(mContext);
                            String url = "https://studev.groept.be/api/a18_sd611/changeSubEventName/" + event.getName() + "/" + event.getId();
                            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                    response -> {},
                                    error -> {});
                            requestQueue.add(stringRequest);
                        }));

                        Toast.makeText(mContext, "Commit!", Toast.LENGTH_SHORT).show();


                    }else{
                        Toast.makeText(mContext, "shouldn't be empty!", Toast.LENGTH_SHORT).show();

                    }

                }
                InputMethodManager im = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                texttview.clearFocus();
                return false;
            }
        });


        viewHolder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((EventSetting)mContext).getThreadArrayList().add(new Thread(()-> {
                    RequestQueue requestQueue = Volley.newRequestQueue(mContext);
                    String url = "https://studev.groept.be/api/a18_sd611/deleteSubEvent/" +  event.getId();
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            response -> {},
                            error -> {});
                    requestQueue.add(stringRequest);
                }));

                removeData(position);
                notifyDataSetChanged();
            }
        });


        return convertView;
    }


//    public Map<Integer,Boolean> getMap(){
//        return isCheck;
//    }
    public void removeData(int position){
        list.remove(position);
    }

}
class SubViewHolder{
    CheckBox finish;
    EditText textView;
    RadioButton delete;
}
