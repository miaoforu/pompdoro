package song.softdev.kuleuven.pomodoro.Logic;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import song.softdev.kuleuven.pomodoro.R;

public class StatisticsActivity extends AppCompatActivity {

    private RequestQueue queue;
    private TextView username_statistics;
    private String username;
    private TextView event_statistics;
    private ArrayList<Event> eventsOfUser = new ArrayList<Event>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        username_statistics=findViewById(R.id.username_statistics);
        event_statistics=findViewById(R.id.event_statistics);
        event_statistics.setText("");

        Intent intent=getIntent();
        Bundle extras=intent.getExtras();
        username=extras.getString(Intent.EXTRA_TEXT);
        username_statistics.setText(username);
        queue= (RequestQueue) Volley.newRequestQueue(this);

        getEventByUsername(username);
    }

    public void getEventByUsername(final String givenText)
    {
        String url ="https://studev.groept.be/api/a18_sd611/getEventByUsername/"+givenText;
        Log.d("URL", url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(String response) {
                        Log.d("APP", "response"+response);
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("ERROR",error.toString());
                        Toast.makeText(getApplicationContext(), "Network failed", Toast.LENGTH_SHORT).show();
                    }
                });
        queue.add(stringRequest);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void parseResponse(String response) {
        try {
            JSONArray data = new JSONArray(response);
            int n = data.length();
            Log.d("HELP","Number of elements to process:"+n);
            if(n==0)return;
            for (int i = 0; i < n; ++i) {
                JSONObject eventObject = data.getJSONObject(i);

                int id_event = eventObject.getInt("id_event");
                String name_event = eventObject.getString("name_event");
                String tag_event = eventObject.getString("tag_event");
                String subName_event = eventObject.getString("subName_event");

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime startTime_event = LocalDateTime.parse(eventObject.getString("startTime_event"), formatter);
                LocalDateTime endTime_event = LocalDateTime.parse(eventObject.getString("endTime_event"), formatter);

                int numTomato_event = eventObject.getInt("numTomato_event");
                String location_event = eventObject.getString("location_event");
                String note_event = eventObject.getString("note_event");
                String toPerson_event = eventObject.getString("toPerson_event");
                int subFrom_event =eventObject.getInt("subFrom_event");

//                Event e = new Event(id_event,name_event,tag_event,subName_event,startTime_event,endTime_event,numTomato_event,note_event,location_event,toPerson_event,subFrom_event);
//                event_statistics.append(id_event+name_event+tag_event+subName_event+startTime_event.toString()+endTime_event.toString()+String.valueOf(numTomato_event)+note_event+location_event);
//                eventsOfUser.add(e);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
