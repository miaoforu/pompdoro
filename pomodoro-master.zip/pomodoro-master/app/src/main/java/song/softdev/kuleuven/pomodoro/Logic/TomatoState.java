package song.softdev.kuleuven.pomodoro.Logic;

public enum TomatoState {IDLE,STUDYING,REST,LONGREST,SUBMIT}

