package song.softdev.kuleuven.pomodoro.UI.TomatoPackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.Logic.Tomato;
import song.softdev.kuleuven.pomodoro.R;

public class TomatoListAdapter extends BaseAdapter {
    private List<Tomato> list=new ArrayList<>();
    private Context mContext;
    private LayoutInflater layoutInflater;
    @SuppressLint("UseSparseArrays")
    private Map<Integer,Boolean> isCheck= new HashMap<>();

    public TomatoListAdapter(Context mContext){
        super();
        this.mContext=mContext;
        this.layoutInflater=LayoutInflater.from(mContext);
        initCheck(false);
    }
    // 初始化map集合
    public void initCheck(boolean flag){
        for(int i=0;i<list.size();i++){
            isCheck.put(i,flag);
        }
    }


    public void setData(List<Tomato> data){
        this.list=data;
    }
    public void addData(Tomato event){
        list.add(0,event);
    }

    @Override
    public int getCount() {
        return list!=null?list.size():0;
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @SuppressLint("SetTextI18n")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder=null;
        if(convertView==null){
            convertView= LayoutInflater.from(mContext).inflate(R.layout.finished_tomato_item,parent,false);
            viewHolder=new ViewHolder();
            viewHolder.startTime=convertView.findViewById(R.id.statTime);
            viewHolder.endTime=convertView.findViewById(R.id.endTime);
            viewHolder.name=convertView.findViewById(R.id.finishedTomatoTitle);
            convertView.setTag(viewHolder);
        }else {
            viewHolder=(ViewHolder)convertView.getTag();
        }
        //拿到对象填充数据
        Tomato event=list.get(position);
        String restToDo="";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        viewHolder.startTime.setText(event.getStartTimeTomato().format(formatter));
        viewHolder.endTime.setText(event.getEndTimeTomato().format(formatter));
        viewHolder.name.setText(event.getWorkDone());


        if(isCheck.get(position)==null){
            isCheck.put(position,false);
        }

//        viewHolder.checkBox.setChecked(isCheck.get(position));



        return convertView;
    }
    public Map<Integer,Boolean> getMap(){
        return isCheck;
    }
    public void removeData(int position){
        list.remove(position);
    }
}

class ViewHolder{
    TextView startTime;
    TextView endTime;
    TextView name;
}