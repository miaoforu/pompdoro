package song.softdev.kuleuven.pomodoro.Logic;

import java.io.Serializable;

public class SubEvent implements Serializable {
    private Event subFrom;
    private int id;
    private int subFromId;
    private String name;
    private boolean isFinished;
    private String person;
    private int expectedTomate;
    public SubEvent(Event subFrom,String name) {
        this.subFrom = subFrom;
        this.name=name;
    }

    public SubEvent(int subFromId, String name, boolean isFinished,String person,int id,int expectedTomato) {
        this.subFromId = subFromId;
        this.name = name;
        this.isFinished = isFinished;
        this.person=person;
        this.id=id;
        this.expectedTomate=expectedTomato;
    }

    public SubEvent(Event subFrom, String name, Boolean isFinished) {
        this.subFrom = subFrom;
        this.name=name;
        this.isFinished=isFinished;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getFinished() {
        return isFinished;
    }

    public void setFinished(Boolean finished) {
        isFinished = finished;
    }


}
