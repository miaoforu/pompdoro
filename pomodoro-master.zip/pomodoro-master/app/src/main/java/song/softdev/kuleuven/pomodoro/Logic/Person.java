package song.softdev.kuleuven.pomodoro.Logic;

import java.util.ArrayList;
import java.util.List;

public class Person {
    private String idPerson;
    private String password;
    private  List<Event> events=new ArrayList<>();
    private List<Tomato>tomatoes=new ArrayList<>();
    private ArrayList<String> breakReasons=new ArrayList<String>();

    public Person(){

    }

    public List<Tomato> getTomatoes() {
        return tomatoes;
    }

    public void setTomatoes(List<Tomato> tomatoes) {
        this.tomatoes = tomatoes;
    }

    public void setIdPerson(String idPerson) {
        this.idPerson = idPerson;
    }
    public String getIdPerson() {
        return idPerson;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getPassword() {
        return password;
    }

    public void setEvents(List<Event> events) {
        this.events =  events;
    }

    public List<Event> getEvents() {
        return events;
    }

    public  int sizeEvents(){
        return events.size();
    }

    public void addBreakReason(String breakReason){
        breakReasons.add(breakReason);
    }
}
