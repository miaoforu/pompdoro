package song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage;

import android.annotation.SuppressLint;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.R;

public class EventListAdapter extends BaseAdapter {
    private List<Event> list=new ArrayList<>();
    private Context mContext;
    private LayoutInflater layoutInflater;
    @SuppressLint("UseSparseArrays")
    private Map<Integer,Boolean> isCheck= new HashMap<>();

    public EventListAdapter(Context mContext){
        super();
        this.mContext=mContext;
        this.layoutInflater=LayoutInflater.from(mContext);
        initCheck(false);
    }
    // 初始化map集合
    public void initCheck(boolean flag){
        for(int i=0;i<list.size();i++){
            isCheck.put(i,flag);
        }
    }
    public void setData(List<Event> data){
        this.list=data;
    }
    public void addData(Event event){
        list.add(0,event);
    }

    @Override
    public int getCount() {
        return list!=null?list.size():0;
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder=null;
        if(convertView==null){
            convertView= LayoutInflater.from(mContext).inflate(R.layout.main_item,parent,false);
            viewHolder=new ViewHolder();
            viewHolder.checkBox=convertView.findViewById(R.id.eventCheckBox1);
            viewHolder.textView=convertView.findViewById(R.id.eventTitle);
            convertView.setTag(viewHolder);
        }else {
            viewHolder=(ViewHolder)convertView.getTag();
        }
        //拿到对象填充数据
        Event event=list.get(position);
        String restToDo="";
        if (event.getExpectedTomato()!=0) {
            restToDo = "(" + event.getNumTomato() + "/" + event.getExpectedTomato() + ")";
        }
        CheckBox CheckBox=viewHolder.checkBox;
        CheckBox.setChecked(event.getStateInUse().equals("finished"));
        viewHolder.textView.setText(event.getNameEvent()+restToDo);
        viewHolder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  CheckBox.setChecked(CheckBox.isChecked());
               boolean isChecked=CheckBox.isChecked();
                String finished=isChecked?"finished":"ongoing";
                event.setStateInUse(finished);
                new Thread(()-> {
                    RequestQueue requestQueue = Volley.newRequestQueue(mContext);
                    String url = "https://studev.groept.be/api/a18_sd611/setEventState/" +finished + "/" + event.getIdEvent();
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            response -> {},
                            error -> {});
                    requestQueue.add(stringRequest);
                }).run();
                notifyDataSetChanged();
            }
        });

        if(isCheck.get(position)==null){
            isCheck.put(position,false);
        }

//        viewHolder.checkBox.setChecked(isCheck.get(position));



        return convertView;
    }
    public Map<Integer,Boolean> getMap(){
        return isCheck;
    }
    public void removeData(int position){
        list.remove(position);
    }
}

class ViewHolder{
    CheckBox checkBox;
    TextView textView;
}