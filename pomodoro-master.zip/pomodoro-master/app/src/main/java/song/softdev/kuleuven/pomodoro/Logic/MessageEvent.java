package song.softdev.kuleuven.pomodoro.Logic;

import java.security.PublicKey;

public class MessageEvent {
    public final String TimerCountString;
    public final int TimeOfCounter;//minute总时长 设置值
    public final int TimerCountInt;
    public final App app;
    public MessageEvent(String TimerCountString,int TimeOfCounter,int TimerCountInt){
        app=null;
        this.TimerCountString=TimerCountString;
        this.TimeOfCounter=TimeOfCounter;
        this.TimerCountInt=TimerCountInt;
    }
    public MessageEvent(App app){
        this.app=app;
        this.TimerCountString=null;
        this.TimeOfCounter=0;
        this.TimerCountInt=0;

    }
}
