package song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.Logic.SubEvent;
import song.softdev.kuleuven.pomodoro.R;
import song.softdev.kuleuven.pomodoro.UI.MainActivity;

import static song.softdev.kuleuven.pomodoro.UI.MainActivity.EVENT_SETTING_BACK;
import static song.softdev.kuleuven.pomodoro.UI.MainActivity.EVENT_SETTING_COMMIT;
import static song.softdev.kuleuven.pomodoro.UI.MainActivity.EVENT_SETTING_DELETE;

public class EventSetting extends AppCompatActivity {

    private RadioButton back;
    private RadioButton commit;
    private ListView mainEvent;
    private ListViewForScrollView subEvent;
    private EventListAdapter adapter;
    private SubEventListAdapter subAdapter;
    private ScrollView sv;
    private EditText addNewSub;
    private RadioButton addSubCommit;
    private EditText expectedTomato;
    private EditText eventTitle;
    private CheckBox isFinished;
    private CheckBox isTopped;
    private Button delete;
    private EditText note;
    private RadioButton submitNote;
    public ThreadGroup threadGroup=new ThreadGroup("event_setting_threadGroup");
    private ArrayList<Thread> threadArrayList=new ArrayList<>();
    List<Event> list=new ArrayList<>();


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_setting);

        subEvent=(ListViewForScrollView)findViewById(R.id.subEvent);
        commit=findViewById(R.id.event_confirm);
        back=findViewById(R.id.event_back);
        Intent intent=this.getIntent();
        final Event event=(Event)intent.getSerializableExtra("event");
        //默认划到顶，解决自定义listView的问题
        sv = (ScrollView) findViewById(R.id.sv_event_setting);
        sv.smoothScrollTo(0, 0);


        subAdapter=new SubEventListAdapter(this);
        subAdapter.setData(event);
        subEvent.setAdapter(subAdapter);

        commit.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {

                ///////运行threadgroup
                threadArrayList.forEach(Thread::run);

                Intent intent1=new Intent(EventSetting.this,EventsFragment.class);
                Bundle b=new Bundle();
                b.putSerializable("event",(Serializable)event);
                intent1.putExtras(b);
                setResult(EVENT_SETTING_COMMIT,intent1);

                finish();
                }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(EventSetting.this,EventsFragment.class);

                setResult(EVENT_SETTING_BACK,intent2);
                finish();
            }
        });
        addNewSub=(EditText)findViewById(R.id.subEventEdit);
        addNewSub.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent eevent) {
                //如果按回车
                if (actionId == EditorInfo.IME_ACTION_DONE ) {
                    if (!addNewSub.getText().toString().equals("")) {
                        String todoName=addNewSub.getText().toString();
                        SubEvent todo = new SubEvent( event, addNewSub.getText().toString());
                        event.addSubEvent(todo);
                        subAdapter.notifyDataSetChanged();//通知刷新adapter
                        threadArrayList.add(new Thread(threadGroup,()-> {
                            RequestQueue requestQueue = Volley.newRequestQueue(EventSetting.this);
                            String url = "https://studev.groept.be/api/a18_sd611/addSubEvent/" + todoName + "/" + event.getIdEvent() + "/" + "0" + "/"+event.getPerson();
                            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                    response -> {},
                                    error -> {});
                            requestQueue.add(stringRequest);
                        }));


                        Toast.makeText(getApplicationContext(), "Commit!", Toast.LENGTH_SHORT).show();


                    }else{
                        Toast.makeText(getApplicationContext(), "shouldn't be empty!", Toast.LENGTH_SHORT).show();

                    }

                }
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                addNewSub.clearFocus();
                addNewSub.setText("");
                return false;
            }
        });
        addSubCommit=(RadioButton)findViewById(R.id.subEventAdd);
        addSubCommit.setOnClickListener(v -> {
            if (!addNewSub.getText().toString().equals("")) {
                String todoName=addNewSub.getText().toString();
                SubEvent todo = new SubEvent( event, addNewSub.getText().toString());
                event.addSubEvent(todo);
                subAdapter.notifyDataSetChanged();//通知刷新adapter
                threadArrayList.add(new Thread(threadGroup,()-> {
                    RequestQueue requestQueue = Volley.newRequestQueue(EventSetting.this);
                    String url = "https://studev.groept.be/api/a18_sd611/addSubEvent/" + todoName + "/" + event.getIdEvent() + "/" + "0" + "/"+event.getPerson();
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            response -> {},
                            error -> {});
                    requestQueue.add(stringRequest);
                }));
                Toast.makeText(getApplicationContext(), "Commit!", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(getApplicationContext(), "shouldn't be empty!", Toast.LENGTH_SHORT).show();

            }
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            addNewSub.clearFocus();
            addNewSub.setText("");
        });


        expectedTomato=(EditText) findViewById(R.id.expectedTomatoNumber);
        if(event.getExpectedTomato()!=0)
        expectedTomato.setText(event.getExpectedTomato()+"");
        expectedTomato.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent eevent) {
                //如果按回车
                if (actionId == EditorInfo.IME_ACTION_DONE ) {
                    if (!expectedTomato.getText().toString().equals("")&&!expectedTomato.getText().toString().equals(event.getExpectedTomato()+"")) {
                        String numExpectedTomato=expectedTomato.getText().toString();
                        threadArrayList.add(new Thread(threadGroup,()-> {
                            RequestQueue requestQueue = Volley.newRequestQueue(EventSetting.this);
                            String url = "https://studev.groept.be/api/a18_sd611/setExpectedTomato/" + numExpectedTomato + "/" + event.getIdEvent();
                            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                    response -> {},
                                    error -> {});
                            requestQueue.add(stringRequest);
                        }));
                        event.setExpectedTomato(Integer.parseInt(expectedTomato.getText().toString()));
                        Toast.makeText(getApplicationContext(), "Commit!", Toast.LENGTH_SHORT).show();
                    }
                }
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                expectedTomato.clearFocus();
                return false;
            }
        });

        eventTitle=(EditText)findViewById(R.id.eventTitle);
        isFinished=(CheckBox)findViewById(R.id.eventCheckBox1);
        isTopped=(CheckBox)findViewById(R.id.eventCheckBox2);
        eventTitle.setText(event.getNameEvent());
        eventTitle.setOnEditorActionListener((v, actionId, eevent) -> {
            //如果按回车
            if (actionId == EditorInfo.IME_ACTION_DONE ) {
                if (!eventTitle.getText().toString().equals("")) {
                    String eventName=eventTitle.getText().toString();
                    event.setNameEvent(eventTitle.getText().toString());
                    Toast.makeText(getApplicationContext(), "Commit!", Toast.LENGTH_SHORT).show();

                    threadArrayList.add(new Thread(threadGroup,()-> {
                        RequestQueue requestQueue = Volley.newRequestQueue(EventSetting.this);
                        String url = "https://studev.groept.be/api/a18_sd611/changeEventName/" + eventName + "/" + event.getIdEvent();
                        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                response -> {},
                                error -> {});
                        requestQueue.add(stringRequest);
                    }));


                }
            }
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            eventTitle.clearFocus();
            return false;
        });


        note=(EditText)findViewById(R.id.eventNote);
        note.setText(event.getNote());
        submitNote=(RadioButton)findViewById(R.id.noteSubmit);
        submitNote.setOnClickListener(v -> {
            String noteContent=note.getText().toString();
            event.setNote(note.getText().toString());
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            note.clearFocus();
            threadArrayList.add(new Thread(threadGroup,()-> {
                RequestQueue requestQueue = Volley.newRequestQueue(EventSetting.this);
                String url = "https://studev.groept.be/api/a18_sd611/addNoteToEvent/" + noteContent + "/" + event.getIdEvent();
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        response -> {},
                        error -> {});
                requestQueue.add(stringRequest);
            }));
            Toast.makeText(getApplicationContext(), "Commit!", Toast.LENGTH_SHORT).show();
        });


        delete=(Button)findViewById(R.id.deleteEvent);
        delete.setOnClickListener(v -> {

            new Thread(threadGroup,()-> {
                RequestQueue requestQueue = Volley.newRequestQueue(EventSetting.this);

                String url = "https://studev.groept.be/api/a18_sd611/deleteEvent/" +event.getIdEvent() + "/" + event.getIdEvent()+"/"+event.getPerson();
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        response -> {},
                        error -> {});
                requestQueue.add(stringRequest);
            }).run();

            Intent intent1=new Intent(EventSetting.this,EventsFragment.class);
            Bundle b=new Bundle();
            b.putSerializable("event",(Serializable)event);
            intent1.putExtras(b);
            setResult(EVENT_SETTING_DELETE,intent1);

            finish();
        });


    }

    public ArrayList<Thread> getThreadArrayList() {
        return threadArrayList;
    }

    public void setThreadArrayList(ArrayList<Thread> threadArrayList) {
        this.threadArrayList = threadArrayList;
    }
}
