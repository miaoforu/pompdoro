package song.softdev.kuleuven.pomodoro.Logic;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import song.softdev.kuleuven.pomodoro.R;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.EventsFragment;
import song.softdev.kuleuven.pomodoro.UI.MainActivity;

import static song.softdev.kuleuven.pomodoro.UI.MainActivity.LOGIN_SUCCESS;

public class LoginActivity extends AppCompatActivity {

    private RequestQueue queue;
    private EditText txtusername;
    private EditText txtpassword;
    private Button btnregister;
    private Button btnlogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        txtusername =findViewById(R.id.username_login);
        txtpassword =findViewById(R.id.password_login);
        btnregister =findViewById(R.id.btnRegister_login);
        btnlogin =findViewById(R.id.btnLogin_login);
        queue= (RequestQueue) Volley.newRequestQueue(this);

        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                }
        });

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkLogin(txtusername.getText().toString());
            }
        });

    }

    public void checkLogin(final String givenText)
    {
        String url ="https://studev.groept.be/api/a18_sd611/checkLogin/"+givenText;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(String response) {
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Network failed", Toast.LENGTH_SHORT).show();
                    }
                });
        queue.add(stringRequest);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void parseResponse(String response) {

        try {
            JSONArray data = new JSONArray(response);
            if(data.length()==0)
            {
                Toast.makeText(getApplicationContext(), "This account doesn't exist.", Toast.LENGTH_SHORT).show();
                return;
            }
            String rightPassword=data.getJSONObject(0).getString("password");
            checkPassword(rightPassword);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void checkPassword(String givenPassword){
        if (txtpassword.getText().toString().equals(givenPassword)){
            Toast.makeText(getApplicationContext(), "WELCOME!"+txtusername.getText().toString(), Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(LoginActivity.this, EventsFragment.class);
            String name=txtusername.getText().toString();
            Bundle b=new Bundle();
            b.putString("userName",name);
            intent.putExtras(b);
            setResult(LOGIN_SUCCESS, intent);
            finish();
        }else{
            Toast.makeText(getApplicationContext(), "Wrong password!", Toast.LENGTH_SHORT).show();
        }
    }
}
