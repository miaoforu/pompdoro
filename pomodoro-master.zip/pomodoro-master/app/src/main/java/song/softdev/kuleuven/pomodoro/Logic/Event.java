package song.softdev.kuleuven.pomodoro.Logic;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Event implements Serializable {
    private String nameEvent;
    private String nameTag;
    private String subName;
    private int numTomato;
    private LocalDateTime nowTime;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private enum state{NOTSTART, ONGOING, FINISHED};
    private state onState;
    private String location;
    private String stateInUse;//是state
    private String note;
    private int idEvent;
    private int expectedTomato;
    private String person;
    private List<SubEvent> subEvents;



    //constructors都是默认一个番茄钟
    //时间设置参数比较多我觉得你可以设计的时候直接调用设置时间的method
    @RequiresApi(api = Build.VERSION_CODES.O)
    public Event(String name){
        split(name);
        subEvents=new ArrayList<>();


//        numTomato=1;
//        setIdEvent();
//        setStartTime();
//        setEndTime();
//        onState=getState();
//        setLocation("nowhere");
//        setNote("nothing");
    }

    public List<SubEvent> getSubEvents() {
        return subEvents;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public Event(String name, int tomato){
        split(name);
        numTomato=tomato;
        setIdEvent();
        setStartTime();
        setEndTime();
        onState=getState();
        setLocation("nowhere");
        setNote("nothing");
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public Event(String name, int tomato, String myNote){
        split(name);
        numTomato=tomato;
        setIdEvent();
        setStartTime();
        setEndTime();
        onState=getState();
        setLocation("nowhere");
        setNote(myNote);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public Event(String name, int tomato, String myNote, String myLocation){
        split(name);
        numTomato=tomato;
        setIdEvent();
        setStartTime();
        setEndTime();
        onState=getState();
        setLocation(myLocation);
        setNote(myNote);
    }
    public Event(int id,String name,String tag,String sub,LocalDateTime startTime,LocalDateTime endTime,int tomato, String note,String state,String person,int expectedTomato){
        this.idEvent=id;
        this.nameEvent=name;
        this.nameTag=tag;
        this.subName=sub;
        this.startTime=startTime;
        this.endTime=endTime;
        this.numTomato=tomato;
        this.note=note;
        this.stateInUse=state;
        this.person=person;
        this.expectedTomato=expectedTomato;
    }


    //第一个小数点处分离"\\."
    public void split(String nameEvent){
        this.nameEvent=nameEvent;
        String[] splitName=nameEvent.split("_");
        this.nameTag=splitName[0];
        this.subName=nameEvent.replace(splitName[0]," ");
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public LocalDateTime getNowTime(){
        this.nowTime=LocalDateTime.now();
        return nowTime;
    }

    public void setIdEvent(int idEvent) {
        this.idEvent = idEvent;
    }

    public void setNameEvent(String nameEvent) {
        this.nameEvent = nameEvent;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setStartTime() {
        startTime=getNowTime();
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setStartTime(int year, int month, int dayOfMonth, int hour, int minute) {
        this.startTime=LocalDateTime.of(year,month,dayOfMonth,hour,minute);
        if(this.startTime.isBefore(getNowTime())){
            this.startTime=getNowTime();
        }
    }
    public LocalDateTime getStartTime() {
        return startTime;
    }

    public String getStateInUse() {
        return stateInUse;
    }

    public void setStateInUse(String stateInUse) {
        this.stateInUse = stateInUse;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public int getExpectedTomato() {
        return expectedTomato;
    }

    public void setExpectedTomato(int expectedTomato) {
        this.expectedTomato = expectedTomato;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setEndTime(){
        endTime=getNowTime().plusMinutes(25);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setEndTime(int year, int month, int dayOfMonth, int hour, int minute) {
        this.endTime=LocalDateTime.of(year,month,dayOfMonth,hour,minute);
        if(this.endTime.isBefore(startTime)){
            this.endTime=startTime.plusMinutes(25);
        }
    }
    public LocalDateTime getEndTime() {
        return endTime;
    }

    //判断state
    @RequiresApi(api = Build.VERSION_CODES.O)
    public state getState(){
        state myState = state.NOTSTART;
        if(getNowTime().isBefore(startTime)){
            myState=state.NOTSTART;
        }else if(getNowTime().isEqual(startTime)||(getNowTime().isAfter(startTime)&&getNowTime().isBefore(endTime))){
            myState=state.ONGOING;
        }else if (getNowTime().isEqual(endTime)||getNowTime().isAfter(endTime)){
            myState=state.FINISHED;
        }
        return myState;
    }
    public void addSubEvent(SubEvent subEvent){
        subEvents.add(subEvent);
    }

    public void setSubEvents(List<SubEvent> subEvents) {
        this.subEvents = subEvents;
    }

    public void setNumTomato(int numTomato){
        this.numTomato=numTomato;
    }
    public int getNumTomato() {
        return numTomato;
    }

    public String getNameEvent() {
        return nameEvent;
    }
    public String getNameTag() {
        return nameTag;
    }
    public String getSubName() {
        return subName;
    }



    public void setLocation(String location) {
        this.location = location;
    }
    public String getLocation() {
        return location;
    }

    public void setNote(String note){
        this.note=note;

    }
    public String getNote() {
        return note;
    }


    //总事件数+1；
    public void setIdEvent() {
//        int numEvents= (int) Person.sizeEvents();
//        this.idEvent = String.valueOf(numEvents+1);
    }
    public int getIdEvent() {
        return idEvent;
    }
}
