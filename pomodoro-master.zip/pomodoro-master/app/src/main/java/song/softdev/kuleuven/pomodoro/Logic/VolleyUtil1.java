package song.softdev.kuleuven.pomodoro.Logic;

import android.content.Context;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;


public class VolleyUtil1 {
    private JSONArray results;
    public void get(Context context, String url, final VolleyCallBack callback1) {
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url,
                response -> {
                    results = response;
                    callback1.onSuccess(results);
                    Log.e("test", "onResponse: ");
                }, error -> {});
        requestQueue.add(jsonArrayRequest);
    }


    public interface VolleyCallBack{
        void onSuccess(JSONArray resultJson);
    }
}