package song.softdev.kuleuven.pomodoro.Logic;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;

public class Tomato implements Serializable {

    private String workDone;
    private int idTomato;
    private String tag;
    private String toEvent;
    private String toPerson;
    private Event belongTo;
    private LocalDateTime startTimeTomato;
    private LocalDateTime endTimeTomato;
    private Duration durationTomato;

    public Tomato(int id,String workDone,String tag,String toEvent,LocalDateTime startTimeTomato,LocalDateTime endTimeTomato,String toPerson){
        this.idTomato=id;
        this.workDone=workDone;
        this.tag=tag;
        this.toEvent=toEvent;
        this.startTimeTomato=startTimeTomato;
        this.endTimeTomato=endTimeTomato;
        this.toPerson=toPerson;
    }
    public Tomato(String workDone,String toEvent,LocalDateTime startTimeTomato,LocalDateTime endTimeTomato,String toPerson){

        this.workDone=workDone;
        this.toEvent=toEvent;
        this.startTimeTomato=startTimeTomato;
        this.endTimeTomato=endTimeTomato;
        this.toPerson=toPerson;
    }

    public String getWorkDone() {
        return workDone;
    }
    public void setWorkDone(String workDone) {
        this.workDone = workDone;
    }

    public int getIdTomato() {
        return idTomato;
    }
    public void setIdTomato(int idTomato) {
        this.idTomato = idTomato;
    }

    public String getTag() {
        return tag;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }

    public Event getBelongTo() {
        return belongTo;
    }
    public void setBelongTo(Event belongTo) {
        this.belongTo = belongTo;
    }

    public LocalDateTime getStartTimeTomato() {
        return startTimeTomato;
    }
    //结束时间是取当时时间那是不是开始时间也是按开始番茄的时间
    //所以我都写的取当前时间
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setStartTimeTomato() {
        this.startTimeTomato = LocalDateTime.now();
    }

    public LocalDateTime getEndTimeTomato() {
        return endTimeTomato;
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setEndTimeTomato(LocalDateTime endTimeTomato) {
        this.endTimeTomato = LocalDateTime.now();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public Duration getDurationTomato(){
        this.durationTomato=Duration.between(getStartTimeTomato(),getEndTimeTomato());
        return durationTomato;
    }

    public String getToEvent() {
        return toEvent;
    }

    public void setToEvent(String toEvent) {
        this.toEvent = toEvent;
    }

    public String getToPerson() {
        return toPerson;
    }

    public void setToPerson(String toPerson) {
        this.toPerson = toPerson;
    }

    public void setStartTimeTomato(LocalDateTime startTimeTomato) {
        this.startTimeTomato = startTimeTomato;
    }

    public void setDurationTomato(Duration durationTomato) {
        this.durationTomato = durationTomato;
    }
}
