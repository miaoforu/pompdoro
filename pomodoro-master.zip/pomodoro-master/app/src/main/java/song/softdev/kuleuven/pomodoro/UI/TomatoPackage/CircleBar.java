package song.softdev.kuleuven.pomodoro.UI.TomatoPackage;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.content.Intent;
import de.greenrobot.event.EventBus;
import de.greenrobot.event.Subscribe;
import de.greenrobot.event.ThreadMode;
import song.softdev.kuleuven.pomodoro.Logic.App;
import song.softdev.kuleuven.pomodoro.Logic.MessageEvent;
import song.softdev.kuleuven.pomodoro.Logic.TomatoState;

public class CircleBar extends View {


    private Paint mBackPaint;
    private Paint mFrontPaint;
    private Paint mTextPaint;
    private float mStrokeWidth = 25;
    private float mHalfStrokeWidth = mStrokeWidth / 2;
    private TomatoState state;
    private float mRadius = 300;
    private RectF mRect;
    private int mProgress = 0;
    //目标值，想改多少就改多少
    private int mTargetProgress = 100;
    private String mStringPrograss;
    private int mMax = 0;
    private int mWidth;
    private int mHeight;


    public CircleBar(Context context) {
        super(context);
        init();
    }

    public CircleBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CircleBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }


    //完成相关参数初始化
    private void init() {
        EventBus.getDefault().register(this);
        mBackPaint = new Paint();
        mBackPaint.setColor(Color.WHITE);
        mBackPaint.setAntiAlias(true);
        mBackPaint.setStyle(Paint.Style.STROKE);
        mBackPaint.setStrokeWidth(mStrokeWidth);

        mFrontPaint = new Paint();
        mFrontPaint.setColor(Color.parseColor("#e85649"));
        mFrontPaint.setAntiAlias(true);
        mFrontPaint.setStyle(Paint.Style.STROKE);
        mFrontPaint.setStrokeWidth(mStrokeWidth);


        mTextPaint = new Paint();

        mTextPaint.setColor(Color.parseColor("#f6f6f6"));
        mTextPaint.setAntiAlias(true);
        mTextPaint.setTextSize(100);
        mTextPaint.setTextAlign(Paint.Align.CENTER);


    }


    //重写测量大小的onMeasure方法和绘制View的核心方法onDraw()
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        mWidth = getRealSize(widthMeasureSpec);
        mHeight = getRealSize(heightMeasureSpec);
        setMeasuredDimension(mWidth, mHeight);

    }


    @Override
    protected void onDraw(Canvas canvas) {
        initRect();
        float angle = mProgress / (float) mMax * 360;
        canvas.drawCircle(mWidth / 2, mHeight / 2, mRadius, mBackPaint);
        canvas.drawArc(mRect, -90, angle, false, mFrontPaint);
        canvas.drawText(""+mStringPrograss+"", mWidth / 2 + mHalfStrokeWidth, mHeight / 2 + mHalfStrokeWidth, mTextPaint);
//        if (mProgress < mTargetProgress) {
//            mProgress += 1;
//            invalidate();
//        }

    }

    public int getRealSize(int measureSpec) {
        int result = 1;
        int mode = MeasureSpec.getMode(measureSpec);
        int size = MeasureSpec.getSize(measureSpec);

        if (mode == MeasureSpec.AT_MOST || mode == MeasureSpec.UNSPECIFIED) {
            //自己计算
            result = (int) (mRadius * 2 + mStrokeWidth);
        } else {
            result = size;
        }

        return result;
    }

    private void initRect() {
        if (mRect == null) {
            mRect = new RectF();
            int viewSize = (int) (mRadius * 2);
            int left = (mWidth - viewSize) / 2;
            int top = (mHeight - viewSize) / 2;
            int right = left + viewSize;
            int bottom = top + viewSize;
            mRect.set(left, top, right, bottom);
        }
    }
    public void transferData(int TimerCountInt,int TimeOfCounter,String TimerCountString,String state){
        mProgress=TimerCountInt;
        mMax= TimeOfCounter*60;
        mTargetProgress= TimeOfCounter*60;
        mStringPrograss=TimerCountString;
        if(state.equals("REST")||state.equals("LONGREST")){
            mFrontPaint.setColor(Color.parseColor("#6e9244"));
        }else mFrontPaint.setColor(Color.parseColor("#e85649"));
    }
    @Subscribe(threadMode = ThreadMode.MainThread)
    public void helloEventBus(MessageEvent messageEvent){

       mProgress= messageEvent.app.getTimerCountInt();
       mMax= messageEvent.app.getTimeOfCounter()*60;
       mTargetProgress= messageEvent.app.getTimeOfCounter()*60;
       mStringPrograss=messageEvent.app.getTimerCountString();
       state=messageEvent.app.getState();
        invalidate();

    }

}