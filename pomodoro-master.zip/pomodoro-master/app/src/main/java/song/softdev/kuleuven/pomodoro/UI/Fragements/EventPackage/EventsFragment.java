package song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import song.softdev.kuleuven.pomodoro.Logic.App;
import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.R;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.EventListAdapter;
import song.softdev.kuleuven.pomodoro.UI.MainActivity;

import static song.softdev.kuleuven.pomodoro.UI.MainActivity.EVENT_SETTING_BACK;
import static song.softdev.kuleuven.pomodoro.UI.MainActivity.EVENT_SETTING_COMMIT;

public class EventsFragment extends Fragment {
    private EditText addNewTask;
    private ListView listview;
    List<Event> list = new ArrayList<>();
    List<Event> finishedList= new ArrayList<>();
    App app;
    MainActivity activity;
    EventListAdapter adapter;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);
        final View view = inflater.inflate(R.layout.fragment_events, container, false);
        //初始化变量
        adapter = new EventListAdapter(getContext());
        listview = (ListView) view.findViewById(R.id.eventListView);
        addNewTask = (EditText) view.findViewById(R.id.addNewTask);
        //初始化listView的adapter   之后把app中的数据导进来
        activity = (MainActivity) getActivity();
        assert activity != null;
        app = activity.getApp();
        list = app.getPerson().getEvents();
        app.getPerson().getEvents().forEach(e->{
            if (e.getStateInUse()==null) e.setStateInUse("ongoing");
            if(e.getStateInUse().equals("ongoing"))
                finishedList.add(e);


        });


        adapter.setData(finishedList);
        listview.setAdapter(adapter);



        //输入任务
        addNewTask.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //如果按回车
                if (actionId == EditorInfo.IME_ACTION_DONE && !addNewTask.getText().toString().equals("")) {
                    Event todo = new Event(addNewTask.getText().toString());//直接添加一个event
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                    LocalDateTime starTime =LocalDateTime.now();
                    todo.setStartTime();
                    finishedList.add(todo);
                    app.getPerson().getEvents().add(todo);
                    activity.setApp(app);
                    adapter.notifyDataSetChanged();//通知刷新adapter
                    new Thread(()-> {
                        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
                        String url = "https://studev.groept.be/api/a18_sd611/addEvent/" +todo.getNameEvent() + "/"+ starTime.format(formatter) + "/"+app.getPerson().getIdPerson();
                        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                response -> {},
                                error -> {});
                        requestQueue.add(stringRequest);
                    }).run();
                    Toast.makeText(getActivity(), "Commit!", Toast.LENGTH_SHORT).show();


                }else  Toast.makeText(getActivity(), "shouldn't be empty!", Toast.LENGTH_SHORT).show();
                InputMethodManager im = (InputMethodManager) Objects.requireNonNull(getActivity()).getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                addNewTask.clearFocus();
                addNewTask.setText("");
                return false;
            }
        });

        //listView点击监听

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getActivity(), "点了", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), EventSetting.class);
                Bundle b = new Bundle();
                b.putSerializable("event", (Serializable) finishedList.get(position));
                intent.putExtras(b);
                startActivityForResult(intent, 0);
            }
        });


        return view;
    }

    public EventListAdapter getAdapter() {
        return adapter;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void fresh(){
        finishedList.clear();
        app.getPerson().getEvents().forEach(e->{
            if (e.getStateInUse()==null) e.setStateInUse("ongoing");
            if(e.getStateInUse().equals("ongoing"))
                finishedList.add(e);


        });
        adapter.notifyDataSetChanged();
    }
}

