package song.softdev.kuleuven.pomodoro.Logic;

import android.annotation.SuppressLint;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.widget.RadioButton;
import android.widget.Switch;

import java.sql.Time;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;

public class App {
    private Person person;
    private String TimerCountString;
    private int TimeOfCounter;//minute总时长 设置值
    private int TimerCountInt;
    private TomatoState state;
    private Duration tomatoDuration;
    private Thread timerThread;
    private int nrOfStudyPeriod;
    private int timeOfWork=25;
    private int timeOfRest=5;
    private int timeOfLongRest=15;
    private int seconds;
    private boolean submitted;
    private LocalDateTime startTime;

    //测试









    //在mainActicity里被调用了

    public void App(){

       state= TomatoState.IDLE;
       TimeOfCounter=timeOfWork;
       nrOfStudyPeriod=0;

       TimerCountString=String.format("%02d:%02d", TimeOfCounter * 60 / 60 % 60, TimeOfCounter * 60 % 60);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void initTimerThread(final App app){
        final Boolean[] ifInterrupted = new Boolean[1];
        timerThread=new Thread(() -> {
            if(!this.getTimerThread().isInterrupted()) {
                seconds = TimeOfCounter * 60;
                while (seconds >= 0) {
                    @SuppressLint("DefaultLocale") String timeLeft = String.format("%02d:%02d", seconds / 60 % 60, seconds % 60);
                    // System.out.println(timeLeft);

                    TimerCountString = timeLeft;
                    TimerCountInt = seconds;
                    EventBus.getDefault().post(new MessageEvent(app));
                    --seconds;
                    if (seconds < 0) {
                        initTimerThread(app);
                        fsmJump();

                        EventBus.getDefault().post(new MessageEvent(app));

                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }
        });

    }

    public void setSubmitted(boolean submitted) {
        this.submitted = submitted;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    public String getTimerCountString() {
        return TimerCountString;
    }

    public void setTimerCountString(String timerCountString) {
        TimerCountString = timerCountString;
    }

    public TomatoState getState() {
        return state;
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setState(TomatoState s) {
        if(this.state!=s) {
            state=s;
            switch (state) {
                case IDLE:
                    TimeOfCounter = timeOfWork;
                    nrOfStudyPeriod = 0;
                    submitted = false;
                    timerThread.interrupt();
                    break;

                case STUDYING:
                    TimeOfCounter = timeOfWork;
                    submitted = false;
                    startTime=LocalDateTime.now();
                    timerThread.start();

                    break;
                case SUBMIT:
                    TimeOfCounter = 0;
                    nrOfStudyPeriod++;
                    timerThread.start();

                    break;
                case REST:
                    TimeOfCounter = timeOfRest;
                    submitted = false;
                    timerThread.start();


                    break;

                case LONGREST:
                    TimeOfCounter = timeOfLongRest;
                    submitted = false;
                    nrOfStudyPeriod=0;
                    timerThread.start();

                    break;
                default:
                    state = TomatoState.IDLE;
                    break;

            }
        }
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public int getTimeOfCounter() {
        return TimeOfCounter;
    }

    public boolean isSubmitted() {
        return submitted;
    }

    public void setTimeOfCounter(int timeOfCounter) {
        TimeOfCounter = timeOfCounter;
    }

    public int getTimerCountInt() {
        return TimerCountInt;
    }

    public void setTimerCountInt(int timerCountInt) {
        TimerCountInt = timerCountInt;
    }

    public Thread getTimerThread() {
        return timerThread;
    }

    public void setTimerThread(Thread timerThread) {
        this.timerThread = timerThread;
    }


    public void countDown(final int time, final RadioButton rb){

        new Thread(){
            @Override
            public void run(){
                int seconds = time * 60;
                while(seconds>0){
                    String timeLeft =String.format("%02d:%02d", seconds / 60 % 60 , seconds % 60);
                    // System.out.println(timeLeft);
                    rb.setText(timeLeft);
                    EventBus.getDefault().post(new MessageEvent(TimerCountString,TimeOfCounter,TimerCountInt));
                    seconds--;
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        }.start();

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void fsmJump()

    {
        switch (state) {
            case STUDYING:
                if (TimerCountInt == 0) {
                    setState(TomatoState.SUBMIT);
                }
                break;
            case SUBMIT:
                if (submitted) {
                    if (nrOfStudyPeriod == 4) {
                        setState(TomatoState.LONGREST);
                    }
                    else {
                        setState(TomatoState.REST);
                    }
                }
                break;
            case REST:
                if (TimerCountInt == 0) {
                    setState(TomatoState.STUDYING);
                }
                break;
            case LONGREST:
                if (TimerCountInt == 0) {
                    setState(TomatoState.STUDYING);
                }
                break;
            default:
                setState(TomatoState.IDLE);
        }
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}
