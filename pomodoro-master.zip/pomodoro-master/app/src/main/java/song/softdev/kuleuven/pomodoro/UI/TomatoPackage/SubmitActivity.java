package song.softdev.kuleuven.pomodoro.UI.TomatoPackage;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.Logic.SubEvent;
import song.softdev.kuleuven.pomodoro.Logic.Tomato;
import song.softdev.kuleuven.pomodoro.R;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.EventSetting;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.EventsFragment;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.ListViewForScrollView;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.SubEventListAdapter;

import static song.softdev.kuleuven.pomodoro.UI.MainActivity.EVENT_SETTING_BACK;
import static song.softdev.kuleuven.pomodoro.UI.MainActivity.SUBMITTED;

public class SubmitActivity extends AppCompatActivity {
   RadioButton back ;
   RadioButton submit;
   EditText name;
   ListViewForScrollView finishedEvent;
   ListViewForScrollView eventsList;
   FinishedListAdapter Adapter1;
   LocalDateTime startTime;
   String person;
   FinishedListAdapter Adapter2;
   List<Event> finishedEvents=new ArrayList<>();
    List<Event> unFinishedEvents=new ArrayList<>();
    ArrayList<String> doEvents=new ArrayList<>();
    List<Tomato> tomatoes=new ArrayList<>();
    String text="";
    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        setContentView(R.layout.activity_submit);
        Intent intent=this.getIntent();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startTime=LocalDateTime.parse(intent.getExtras().getString("startTime"),formatter);
        }
        person=intent.getExtras().getString("person");
        final List<Event> event=(List<Event>) intent.getSerializableExtra("event");
        if (event!=null){
        event.forEach(e-> {
            if(e.getStateInUse()==null){
                e.setStateInUse("ongoing");
            }
            if (e.getStateInUse().equals("finished"))
                finishedEvents.add(e);
            else
                unFinishedEvents.add(e);

        });}
        finishedEvent=(ListViewForScrollView)findViewById(R.id.finishedEvent);
        eventsList=(ListViewForScrollView)findViewById(R.id.EventsList) ;
        Adapter1=new FinishedListAdapter(this);
        Adapter1.setData(finishedEvents);
        finishedEvent.setAdapter(Adapter1);
        Adapter2=new FinishedListAdapter(this);
        Adapter2.setData(unFinishedEvents);
        eventsList.setAdapter(Adapter2);


        back=(RadioButton)findViewById(R.id.event_back2);
        back.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SubmitActivity.this, EventsFragment.class);
                setResult(EVENT_SETTING_BACK,intent);
                finish();
            }
        });
        name=(EditText)findViewById(R.id.submitEdit) ;
        finishedEvent.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                text=text+"+"+finishedEvents.get(position).getNameEvent();
                name.setText(text);
                doEvents.add(finishedEvents.get(position).getIdEvent()+"");
            }
        });
        eventsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                text=text+"+"+unFinishedEvents.get(position).getNameEvent();
                name.setText(text);
                doEvents.add(unFinishedEvents.get(position).getIdEvent()+"");

            }
        });
        name.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent eevent) {
                //如果按回车
                if (actionId == EditorInfo.IME_ACTION_DONE ) {
                    InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    name.clearFocus();
                }

                return false;
            }
        });

        submit=(RadioButton)findViewById(R.id.submitAdd);
        submit.setOnClickListener(v -> {
            if (!name.getText().toString().equals("")) {
                String todoName=name.getText().toString();
                if(doEvents.size()!=0){
                    doEvents.forEach(e->{
                        Tomato tomato=new Tomato(todoName,e,startTime,LocalDateTime.now(),person);
                        tomatoes.add(tomato);

                            RequestQueue requestQueue = Volley.newRequestQueue(this);
                            String url = "https://studev.groept.be/api/a18_sd611/addTomato/ "+ todoName + "/" + e + "/" + person + "/"+startTime+"/"+LocalDateTime.now();
                            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                    response -> {},
                                    error -> {});
                            requestQueue.add(stringRequest);
                    });
                }else {
                    Tomato tomato=new Tomato(todoName,"null",startTime,LocalDateTime.now(),person);
                    tomatoes.add(tomato);

                    RequestQueue requestQueue = Volley.newRequestQueue(this);
                    String url = "https://studev.groept.be/api/a18_sd611/addTomato/ "+ todoName + "/" + "null" + "/" + person + "/"+startTime+"/"+LocalDateTime.now();
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            response -> {},
                            error -> {});
                    requestQueue.add(stringRequest);
                }


                Toast.makeText(getApplicationContext(), "Submitted!", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(getApplicationContext(), "shouldn't be empty!", Toast.LENGTH_SHORT).show();

            }
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            Intent intent1=new Intent(this,EventsFragment.class);
            Bundle bundle=new Bundle();
            event.clear();
            event.addAll(finishedEvents);
            event.addAll(unFinishedEvents);
            bundle.putSerializable("events",(Serializable)event);
            bundle.putSerializable("tomatoes",(Serializable)tomatoes);
            intent1.putExtras(bundle);
            setResult(SUBMITTED,intent1);
            finish();
        });





















    }
}
