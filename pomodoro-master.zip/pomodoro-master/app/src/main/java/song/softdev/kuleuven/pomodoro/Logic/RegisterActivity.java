package song.softdev.kuleuven.pomodoro.Logic;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import song.softdev.kuleuven.pomodoro.R;

public class RegisterActivity extends AppCompatActivity {

    private EditText setUsername;
    private EditText setPassword;
    private EditText passwordAgain;
    private Button btnRegister_register;
    private RequestQueue queue;
    private boolean checkPassword;
    private String myUsername;
    private String myPassword;
    private String myPasswordAgain;
    private String Response;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        setUsername=findViewById(R.id.username_register);
        setPassword=findViewById(R.id.password_register);
        passwordAgain=findViewById(R.id.passwordagain_register);
        btnRegister_register=findViewById(R.id.btnRegister_register);

        queue= (RequestQueue) Volley.newRequestQueue(this);

        btnRegister_register.setOnClickListener(v -> {
            myUsername=setUsername.getText().toString();
            myPassword=setPassword.getText().toString();
            myPasswordAgain=passwordAgain.getText().toString();
            checkUsername(myUsername);
            //在volleyUtil监听器里check了密码
        });
    }

    private void checkUsername(final String givenText){
        checkPassword=false;
        String url ="https://studev.groept.be/api/a18_sd611/checkLogin/"+givenText;
        StringRequest stringRequest = new StringRequest(url,
                response -> {},
                error->{} );
        queue.add(stringRequest);

        VolleyUtil volleyUtil=new VolleyUtil();
        volleyUtil.get(this, url, result -> {
            Response=result;

            if(Response.equals("[]")){
                checkPassword=true;

                    if(checkPasswordAgain()){
                        registerUserData(myUsername,myPassword);
                    }else  Toast.makeText(getApplicationContext(), "Please check the password.", Toast.LENGTH_SHORT).show();
                    
            }else Toast.makeText(getApplicationContext(), "This username exist.", Toast.LENGTH_SHORT).show();
        });
        }



    private boolean checkPasswordAgain() {
        if(( myPassword.equals("")) || ( myPasswordAgain.equals(""))){
            Log.d("APP", "null");
            return false;
        }else{
            if(myPassword.equals(myPasswordAgain)){
                Log.d("APP", "equal");
                return true;}
            else{
                Log.d("APP", "not equal");
                return false;}}
    }

    private void registerUserData(final String name,final String password){
        String url="https://studev.groept.be/api/a18_sd611/insertUser/"+name+"/"+password;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> Toast.makeText(getApplicationContext(), name+", please log in.", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(getApplicationContext(), "Network failed", Toast.LENGTH_SHORT).show());
        queue.add(stringRequest);
        checkPassword=false;
        finish();

    }
}
