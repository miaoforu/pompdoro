package song.softdev.kuleuven.pomodoro.UI;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

import de.greenrobot.event.EventBus;
import de.greenrobot.event.Subscribe;
import de.greenrobot.event.ThreadMode;
import song.softdev.kuleuven.pomodoro.Logic.App;
import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.Logic.LoginActivity;
import song.softdev.kuleuven.pomodoro.Logic.MessageEvent;
import song.softdev.kuleuven.pomodoro.Logic.Person;
import song.softdev.kuleuven.pomodoro.Logic.SubEvent;
import song.softdev.kuleuven.pomodoro.Logic.Tomato;
import song.softdev.kuleuven.pomodoro.Logic.TomatoState;
import song.softdev.kuleuven.pomodoro.R;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.EventsFragment;
import song.softdev.kuleuven.pomodoro.UI.Fragements.HistoryPackage.HistoryFragment;
import song.softdev.kuleuven.pomodoro.UI.Fragements.ProfileFragment;
import song.softdev.kuleuven.pomodoro.UI.Fragements.StatisticFragment;
import song.softdev.kuleuven.pomodoro.UI.TomatoPackage.HistoryActivity;
import song.softdev.kuleuven.pomodoro.UI.TomatoPackage.SubmitActivity;
import song.softdev.kuleuven.pomodoro.UI.TomatoPackage.TomatoActivity;


@RequiresApi(api = Build.VERSION_CODES.O)
public class MainActivity extends AppCompatActivity {
    public static final int EVENT_SETTING_COMMIT  =1;
    public static final int EVENT_SETTING_BACK  =2;
    public static final int EVENT_SETTING_DELETE=3;
    public static final int LOGIN_SUCCESS=4;
    public static final int SUBMITTED=5;
    public static final int HISTORY=6;

    private Timer timer;
    private TimerTask timerTask;
    private Handler handler = new Handler();

    private RadioGroup bottomNav;
    private RadioButton timerButton;
    private RadioButton testButton;
    //记得删！！！！！！！！！！！！！！！！！
    RadioButton eventFrag;
    private EventsFragment f_events;
    private HistoryFragment f_history;
    private StatisticFragment f_statistic;
    private ProfileFragment f_profile;
    private Fragment[] mfragments;
    private int mIndex;
    private ImageButton clockButton;
    private RadioButton myProfileBtn;
    private String TimerCountString;
    private int TimeOfCounter;
    private int TimerCountInt;
    private boolean times;

    private String username;

    HashMap<String,Event> eventMap = new HashMap<>();
    HashMap<String,Tomato> tomatoMap = new HashMap<>();

    List<Event> events=new ArrayList<>();
    List<SubEvent> subEvents=new ArrayList<>();
    List<List<SubEvent>> subEventsLists=new ArrayList<>();
    List<Tomato> tomatoes=new ArrayList<>();
    App app= new App();
    Person person=new Person();
    //测试
    Event event1=new Event("test1");

    SubEvent subEvent1=new SubEvent(event1,"subTest1");
    SubEvent subEvent2=new SubEvent(event1,"subTest2");
    Event event2=new Event("test2");




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        EventBus.getDefault().register(this);
        app.App();
        startTimer();
        eventFrag=(RadioButton) findViewById(R.id.eventsTable);
        //测试用

        subEvents.add(subEvent1);
        subEvents.add(subEvent2);
        event1.setSubEvents(subEvents);
        event1.setIdEvent(11);
        event2.setIdEvent(22);
        events.add(event1);

        events.add(event2);
        person.setEvents(events);
        app.setPerson(person);

        app.initTimerThread(app);
        initView();
        initFragment();
        clockButton=(ImageButton)findViewById(R.id.clockButton);
        clockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runTimer();
            }
        });

        timerButton=(RadioButton)findViewById(R.id.timerButton);
        testButton=(RadioButton)findViewById(R.id.radioButton2);
        myProfileBtn = (RadioButton)findViewById(R.id.myProfile);
        timerButton.setText(app.getTimerCountString());
        timerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               //设置打开线程和线程开始条件，否则会重复开始
               runTimer();
            }
        });

        testButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu=new PopupMenu(MainActivity.this,v);
                MenuInflater inflater=popupMenu.getMenuInflater();
                if(app.getState()==TomatoState.IDLE)
                inflater.inflate(R.menu.popup_menu, popupMenu.getMenu());
                else
                    inflater.inflate(R.menu.popup_menu2, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(item -> {
                    switch (item.getItemId()) {
                        case R.id.eventHistory:
                            Toast.makeText(MainActivity.this, "history", Toast.LENGTH_SHORT).show();
                            Intent intent1=new Intent(MainActivity.this,HistoryActivity.class);
                            Bundle bundle=new Bundle();
                            bundle.putSerializable("event", (Serializable) app.getPerson().getEvents());
                            bundle.putString("where","Main");
                            intent1.putExtras(bundle);
                            startActivityForResult(intent1,0);
                            break;
//                        case R.id.AbandonTomato:
//                            Toast.makeText(MainActivity.this, "abandon", Toast.LENGTH_SHORT).show();
//                            app.setState(TomatoState.SUBMIT);
//                            timerButton.setText("25:00");
//
//
//                            break;
                        case R.id.shift:
                            Toast.makeText(MainActivity.this, "shift", Toast.LENGTH_SHORT).show();
                            if(app.getTimerCountInt()!=0)
                                app.setSeconds(2);
                            else {
                                app.setSubmitted(true);
                                app.fsmJump();
                            }
                            break;
                        case R.id.fresh:
                            f_events.fresh();
                            break;

                        default:
                            break;
                    }
                    return false;
                });
                popupMenu.show();

            }







        });

        myProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, LoginActivity.class);
                startActivityForResult(intent,0);
            }
        });

    }














    public App getApp() {
        return app;
    }

    public void setApp(App app) {
        this.app = app;
        //上载到服务器
    }

    public void runTimer(){
        switch (app.getState()){
            case IDLE:
                app.initTimerThread(app);
                timerButton.setText("25:00");
                app.setState(TomatoState.STUDYING);
                break;
            case SUBMIT:
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                Intent intent0=new Intent(MainActivity.this, SubmitActivity.class);
                Bundle b=new Bundle();
                b.putSerializable("event", (Serializable) app.getPerson().getEvents());
                b.putString("startTime",app.getStartTime().format(formatter));
                b.putString("person",username);
                intent0.putExtras(b);

                startActivityForResult(intent0,0);
                break;
                default:
                Intent intent=new Intent(MainActivity.this, TomatoActivity.class);
                Bundle b1=new Bundle();
                b1.putSerializable("event", (Serializable) app.getPerson().getEvents());
                b1.putString("where","tomato");
                b1.putSerializable("tomato", (Serializable) app.getPerson().getTomatoes());
                b1.putString("state",app.getState().toString());
                b1.putString("TimerCountString",TimerCountString);
                b1.putInt("TimerOfCounter",TimeOfCounter);
                b1.putInt("TimerCountInt",TimerCountInt);
                intent.putExtras(b1);

                startActivityForResult(intent,0);
                break;
        }
    }
    private void initView(){
        bottomNav=findViewById(R.id.bottomNavigator);
        bottomNav.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                //遍历radio group里的子控件
                for(int index=0;index<group.getChildCount();index++){
                    //获取某位置的rb
                    if(index==1){index=2;}//跳过第三个View 否则报错
                    RadioButton rb=(RadioButton)group.getChildAt(index);
                    if(rb.isChecked()){
                        setIndexSelected(index);
                        break;
                    }
                }
            }
        });
    }
    private void initFragment(){
        f_events=new EventsFragment();
        f_history=new HistoryFragment();

        f_statistic= new StatisticFragment();
        f_profile=new ProfileFragment();
        mfragments=new Fragment[]{f_events,null,f_profile};
        //开启事务
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        //添加首页
        fragmentTransaction.add(R.id.content,f_events).commit();
        //默认第零个
        setIndexSelected(0);
    }
    //选中与隐藏fragment
    private void setIndexSelected(int index){
        if(mIndex==index){
            return;
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        //隐藏
        fragmentTransaction.hide(mfragments[mIndex]);
        //判断是否添加
        if(!mfragments[index].isAdded()){
            fragmentTransaction.add(R.id.content,mfragments[index]).show(mfragments[index]);
        }
        else {
            fragmentTransaction.show(mfragments[index]);
        }
        fragmentTransaction.commit();
        mIndex=index;
    }
    @Subscribe(threadMode = ThreadMode.MainThread)
    public void helloEventBus(MessageEvent messageEvent){
        if(messageEvent.app!=null) {

            timerButton.setText(messageEvent.app.getTimerCountString());
            testButton.setText(messageEvent.app.getState()+" "+app.isSubmitted());
            TimerCountString=messageEvent.app.getTimerCountString();
            TimeOfCounter=messageEvent.app.getTimeOfCounter();
            TimerCountInt=messageEvent.app.getTimerCountInt();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (resultCode){
            case EVENT_SETTING_BACK:
                break;

            case EVENT_SETTING_COMMIT:
                assert data != null;
                final Event event=(Event)data.getSerializableExtra("event");
                List<Event> events=app.getPerson().getEvents();
                for(int i=0;i<events.size();i++){
                    if(events.get(i).getIdEvent()==(event.getIdEvent())){
                        events.set(i,event);
                    }
                }
                app.getPerson().setEvents(events);
                setApp(app);
                f_events.getAdapter().notifyDataSetChanged();
                Toast.makeText(this,"Changed!",Toast.LENGTH_SHORT).show();
                break;

            case EVENT_SETTING_DELETE:
                assert data != null;
                final Event event1=(Event)data.getSerializableExtra("event");
                final List<Event> events1=app.getPerson().getEvents();
                events1.removeIf(e-> e.getIdEvent()==(event1.getIdEvent()));
                app.getPerson().setEvents(events1);
                setApp(app);
                f_events.getAdapter().notifyDataSetChanged();
                Toast.makeText(this,"Changed!",Toast.LENGTH_SHORT).show();
                break;

            case LOGIN_SUCCESS:
                //login过来的
                assert data != null;
                Bundle b=data.getExtras();
                assert b != null;
                username=b.getString("userName");
                initData(username);
                setIndexSelected(0);
                eventFrag.setChecked(true);
                f_events.fresh();


                break;
            case SUBMITTED:
                Bundle bundle=data.getExtras();
                final List<Tomato> addTomatoes=(List<Tomato>) data.getSerializableExtra("tomatoes");
                List<Event> submitEvents=(List<Event>) data.getSerializableExtra("events");
                app.getPerson().setEvents(submitEvents);
                addTomatoes.forEach(t->{
                    app.getPerson().getTomatoes().add(t);
                });
                app.getPerson().getEvents().forEach(e->{
                    e.setNumTomato(countTomatoOfEvent(e.getIdEvent()+""));
                });
                f_events.getAdapter().notifyDataSetChanged();
                app.setSubmitted(true);
                app.fsmJump();

                break;
            case HISTORY:
                Bundle bun=data.getExtras();
                List<Event> historytEvents=(List<Event>) data.getSerializableExtra("events");
                app.getPerson().setEvents(historytEvents);
                break;
            default:
                Toast.makeText(this,"back",Toast.LENGTH_SHORT).show();
                break;
        }
    }


    //数据库获取数据
    public void initData(String userName){
        Log.d("test","init");
        Toast.makeText(this,"from login",Toast.LENGTH_SHORT).show();
        tomatoes.clear();
        subEvents.clear();
        subEventsLists.clear();
        events.clear();

        getTomatoDataByUsername(userName);
        getEventByUsername(userName,events);
        person.setTomatoes(tomatoes);
        person.setEvents(events);
        person.setIdPerson(userName);
        app.setPerson(person);
        setApp(app);
        f_events.getAdapter().notifyDataSetChanged();

    }
    public void getEventByUsername(String name,List<Event> events) {
        final RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);


        String url="https://studev.groept.be/api/a18_sd611/getEventByUsername/"+username;
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest( url,
                response -> {
                    try {

                        for (int i = 0; i < response.length(); i++) {

                            JSONObject eventObject = response.getJSONObject(i);

                            int id_event = eventObject.getInt("id_event");
                            String name_event = eventObject.getString("name_event");
                            String tag_event = eventObject.getString("tag_event");
                            String subName_event = eventObject.getString("subName_event");

                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                            LocalDateTime startTime_event = LocalDateTime.parse(eventObject.getString("startTime_event"), formatter);
                            String endTime=eventObject.getString("endTime_event");
                            LocalDateTime endTime_event=null;
                            if (!endTime.equals("null"))
                            endTime_event = LocalDateTime.parse(eventObject.getString("endTime_event"), formatter);

                            int numTomato_event = eventObject.getInt("numTomato_event");
                            String location_event = eventObject.getString("location_event");
                            if(location_event.equals("null")) location_event="ongoing";
                            String note_event = eventObject.getString("note_event");
                            if(note_event.equals("null")) note_event="";

                            int expectedTomato=eventObject.getInt("expectedTomato");

                            subEventsLists.add(i, new ArrayList<>());
                            Event e = new Event(id_event, name_event, tag_event, subName_event, startTime_event, endTime_event, numTomato_event, note_event, location_event,username,expectedTomato);
                            getSubEventsByEventName(id_event,subEventsLists.get(i));

                            e.setSubEvents(subEventsLists.get(i));
                            subEvents.clear();
                                e.setNumTomato(countTomatoOfEvent(e.getIdEvent()+""));
                               events.add(e);

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getApplicationContext(), "Network failed", Toast.LENGTH_SHORT).show());

       requestQueue.add(jsonArrayRequest);



    }
    public int countTomatoOfEvent(String id){
        AtomicInteger i= new AtomicInteger();
        tomatoes.forEach(e->{
            if(e.getToEvent().equals(id)){
                i.getAndIncrement();
            }
        });
        return i.get();
    }
    public void getTomatoDataByUsername(final String givenText){
        final RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        String url ="https://studev.groept.be/api/a18_sd611/getTomatoByUsername/"+givenText;
        Log.d("URL", url);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest( url,
                 response -> {
                    try {
                        int n = response.length();
                        for (int i = 0; i < n; i++) {
                            JSONObject tomatoObject = response.getJSONObject(i);
                            String name_tomato = tomatoObject.getString("toEvent_tomato");

                            int id_tomato = tomatoObject.getInt("id_tomato");
                            String workDone_tomato = tomatoObject.getString("workDone_tomato");
                            String tag_tomato = tomatoObject.getString("tag_tomato");
                            String toEvent_tomato = tomatoObject.getString("toEvent_tomato");


                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                            LocalDateTime startTime_tomato = LocalDateTime.parse(tomatoObject.getString("startTime_tomato"), formatter);
                            LocalDateTime endTime_tomato = LocalDateTime.parse(tomatoObject.getString("endTime_tomato"), formatter);

                            Tomato tomato= new Tomato(id_tomato,workDone_tomato,tag_tomato,toEvent_tomato,startTime_tomato,endTime_tomato,username);
                            tomatoes.add(tomato);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getApplicationContext(), "Network failed", Toast.LENGTH_SHORT).show());
        requestQueue.add(jsonArrayRequest);
    }
    public void getSubEventsByEventName(int eventId,List<SubEvent> subEvents){
        RequestQueue requestQueue=Volley.newRequestQueue(MainActivity.this);

        String url="https://studev.groept.be/api/a18_sd611/getSubEventsByEventName/"+username+"/"+eventId;
        JsonArrayRequest Request =new JsonArrayRequest(url, response -> {
            int n = response.length();
            try {
                for (int i = 0; i<n; i++){

                    JSONObject object=response.getJSONObject(i);
                    String name =object.getString("name");
                    int evnetId=object.getInt("subFrom");
                    int id=object.getInt("idsubEventData");
                    int isFinished=object.getInt("isFinished");
                    int expectedTomato=object.getInt("expectedTomato");
                    SubEvent subEvent=new SubEvent(eventId,name,isFinished==1,username,id,expectedTomato);

                    subEvents.add(subEvent);

                }
            }catch (JSONException e) {
                e.printStackTrace();
            }


        }, error ->
            Toast.makeText(getApplicationContext(), "Network failed", Toast.LENGTH_SHORT).show()
        );
        requestQueue.add(Request);

    }



    //To stop timer
    private void stopTimer(){
        if(timer != null){
            timer.cancel();
            timer.purge();
        }
    }

    //To start timer
    private void startTimer(){
        timer = new Timer();
        timerTask = new TimerTask() {
            public void run() {
                handler.post(new Runnable() {
                    public void run(){
                        f_events.fresh();
                    }
                });
            }
        };
        timer.schedule(timerTask, 5000, 5000);
    }





}