package song.softdev.kuleuven.pomodoro.Logic;
import android.content.Context;
import android.util.Log;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


public class VolleyUtil {
    private String results;
    public void get(Context context, String url, final VolleyCallback callback) {
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        StringRequest stringRequest = new StringRequest(url,
                response -> {
                    results = response;
                    callback.onSuccess(results);
                    Log.e("recycler", "onResponse: " + results);
                }, error -> {});
        requestQueue.add(stringRequest);
    }

    public interface VolleyCallback {
        void onSuccess(String result);
    }
}