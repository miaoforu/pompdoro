package song.softdev.kuleuven.pomodoro.UI.TomatoPackage;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.Logic.Tomato;
import song.softdev.kuleuven.pomodoro.R;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.EventsFragment;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.ListViewForScrollView;

import static song.softdev.kuleuven.pomodoro.UI.MainActivity.EVENT_SETTING_BACK;
import static song.softdev.kuleuven.pomodoro.UI.MainActivity.HISTORY;
import static song.softdev.kuleuven.pomodoro.UI.MainActivity.SUBMITTED;

public class HistoryActivity extends AppCompatActivity {
   RadioButton back ;
   RadioButton submit;
   EditText name;
   ListViewForScrollView finishedEvent;
   ListViewForScrollView eventsList;
   FinishedListAdapter Adapter1;
   LocalDateTime startTime;
   String person;
   String where;
   FinishedListAdapter Adapter2;
   List<Event> finishedEvents=new ArrayList<>();
    List<Event> unFinishedEvents=new ArrayList<>();
    ArrayList<String> doEvents=new ArrayList<>();
    List<Tomato> tomatoes=new ArrayList<>();
    String text="";
    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_history);
        Intent intent=this.getIntent();
        where=intent.getExtras().getString("where");
        final List<Event> event=(List<Event>) intent.getSerializableExtra("event");
        if (event!=null){
        event.forEach(e-> {
            if(e.getStateInUse()==null){
                e.setStateInUse("ongoing");
            }
            if (e.getStateInUse().equals("finished"))
                finishedEvents.add(e);
            else
                unFinishedEvents.add(e);

        });}
        finishedEvent=(ListViewForScrollView)findViewById(R.id.finishedHistoryEvent);

        Adapter1=new FinishedListAdapter(this);
        Adapter1.setData(finishedEvents);
        finishedEvent.setAdapter(Adapter1);



        back=(RadioButton)findViewById(R.id.event_back3);
        back.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                Intent intent1;
                if (where.equals("main")){
                    intent1=new Intent(HistoryActivity.this,EventsFragment.class);
                }else  intent1=new Intent(HistoryActivity.this,TomatoActivity.class);

                Bundle bundle=new Bundle();
                event.clear();
                event.addAll(finishedEvents);
                event.addAll(unFinishedEvents);
                bundle.putSerializable("events",(Serializable)event);
                intent1.putExtras(bundle);
                setResult(HISTORY,intent1);
                finish();
            }
        });




























    }
}
