package song.softdev.kuleuven.pomodoro.UI.TomatoPackage;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuInflater;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

import song.softdev.kuleuven.pomodoro.Logic.Event;
import song.softdev.kuleuven.pomodoro.Logic.Tomato;
import song.softdev.kuleuven.pomodoro.Logic.TomatoState;
import song.softdev.kuleuven.pomodoro.R;
import song.softdev.kuleuven.pomodoro.UI.Fragements.EventPackage.ListViewForScrollView;
import song.softdev.kuleuven.pomodoro.UI.MainActivity;

public class TomatoActivity extends AppCompatActivity {
    private RadioGroup radioGroup;
    private Fragment f_clock;
    private Fragment f_tasks;
    private RadioButton submenue;
    private RadioButton back;
    private TextView date;
    private TextView num;
    List<Tomato> tomatoes=new ArrayList<>();
    List<Event> events=new ArrayList<>();
    private ListViewForScrollView tomatoList;
    private TomatoListAdapter tomatoListAdapter;
    private CircleBar circleBar;
    String where;

    private int i;
    Timer myTimer=new Timer();
    public void increament(){
        i++;
    }
    @SuppressLint("SetTextI18n")
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tomato);
        Intent intent=this.getIntent();
        Bundle b=intent.getExtras();
        tomatoes=(List<Tomato>) intent.getSerializableExtra("tomato");
        events=(List<Event>) intent.getSerializableExtra("event");
        where=intent.getExtras().getString("where");


//        tomatoes.add(new Tomato(1,"test","1", "1",LocalDateTime.now(),LocalDateTime.now(),"fm"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("d MMM ");
        tomatoes.removeIf(t->
            !t.getEndTimeTomato().format(formatter).equals(LocalDateTime.now().format(formatter))
        );
        tomatoList=(ListViewForScrollView)findViewById(R.id.tomatoList);
        tomatoListAdapter=new TomatoListAdapter(this);
        tomatoListAdapter.setData(tomatoes);
        tomatoList.setAdapter(tomatoListAdapter);
        int number=tomatoes.size();
        num=(TextView)findViewById(R.id.numOfTomatoDone);

         num.setText(number+"");
        date=(TextView)findViewById(R.id.todayDate);
        LocalDate ddate=LocalDate.now();
        date.setText(ddate.getDayOfWeek().toString()+","+LocalDateTime.now().format(formatter1));

        circleBar=(CircleBar)findViewById(R.id.circleBar);
        circleBar.transferData(b.getInt("TimerCountInt"),b.getInt("TimerOfCounter"),b.getString("TimerCountString"),b.getString("state"));
        submenue=(RadioButton)findViewById(R.id.submenu) ;

        submenue.setOnClickListener(v -> {
            PopupMenu popupMenu=new PopupMenu(this,v);
            MenuInflater inflater=popupMenu.getMenuInflater();
            inflater.inflate(R.menu.popup_menu3, popupMenu.getMenu());
            popupMenu.setOnMenuItemClickListener(item -> {
                switch (item.getItemId()) {

                    case R.id.AbandonTomato:
                        Toast.makeText(this, "history", Toast.LENGTH_SHORT).show();
                        Intent intent1=new Intent(this,HistoryActivity.class);
                        Bundle bundle=new Bundle();
                        bundle.putSerializable("event", (Serializable) events);
                        bundle.putString("where",where);
                        intent1.putExtras(bundle);
                        startActivityForResult(intent1,0);

                        break;
                    default:
                        break;
                }
                return false;
            });
            popupMenu.show();

        });


        back=(RadioButton)findViewById(R.id.event_back1);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }





}
